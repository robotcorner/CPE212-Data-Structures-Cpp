#include <iostream>
#include <cstdlib>
#include "graph.h"

using namespace std;

int main(int argv, char** argc)
{
  GraphType<char> charGraph;
  
}
