#include <iostream>
#include <ostream>

void queue_driver();

using namespace std;

int main()
{
int i;
int user_input;
int a[10];
int*  array = new int[100];
cout << "hello1 " << endl;
for(i=0;i<=10;i++) a[i]=0;
cout << " hello2 " << endl;
a[1000000] = 0;                      //set a[1] = 0
cout << "hello3 " << endl;

cout << "input a test value " << endl;
cin >> user_input ;
while(user_input != 9999)

{
  if(user_input >1) cout << "greater than 1 " << endl;
  if(user_input == 1) cout << "a 1 was entered " << endl;
  if(user_input == 2) cout << "a 2 was entered " << endl;
  if(user_input == 10)
{
 cout << " a 10 was entered ";
 a[user_input] = 100;
}
  cout << "input next value " << endl;
  cin >> user_input;
}


// now test the queue software 

queue_driver();

 }


