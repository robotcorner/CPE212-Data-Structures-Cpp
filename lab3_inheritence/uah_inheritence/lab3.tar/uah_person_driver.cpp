// THIS FILE TESTS THE UAH PERSON CPP

#include <iostream>
#include "uah_person.h"
#include "uah_employee.h"
#include "uah_student.h"
#include "extended.h"

using namespace std;

int main()
{
//cout << "trying to create  persone jeff1 " << endl;
uah_person jeff1;
//cout << "trying to create person jeff2 " << endl;
uah_person jeff2("jeff2", "jeffemail", "jeffanumber");
//cout << "trying to create employee jeff3 " << endl;
uah_employee jeff3;
//cout << "trying to create employee jeff4 " << endl;
uah_employee jeff4("jeff4", "jeffmail", "jeffanumber", "jeffsalary");
//cout << "trying to create employee jeff5 " << endl;
uah_student jeff5;
//cout << "trying to create employee jeff6 " << endl;
uah_student jeff6("jeff6", "jeffmail", "jeffanumber", "jeffgpa");

uah_student student1("bob1", "mail1", "anumber1", "gpa1");
uah_student student2("bob2", "mail2", "anumber2", "gpa2");
uah_student student3("bob3", "mail3", "anumber3", "gpa3");
uah_student student4("bob4", "mail4", "anumber4", "gpa4");

cout <<"  jeff1  ";
jeff1.print(); 
cout << endl;

cout <<"  jeff2  ";
jeff2.print(); 
cout << endl;

cout <<"  jeff3  ";
jeff3.print();
cout << endl;

cout <<"  jeff4  ";
jeff4.print();
cout << endl;

cout <<"  jeff5  ";
jeff5.print();
cout << endl;

cout <<"  jeff6  ";
jeff6.print();
cout << endl;

cout <<"  Student1  ";
student1.add_enrolled_class(104);
student1.print();
cout << endl;

cout <<"  Student2  ";
student2.add_enrolled_class(115);
student2.add_enrolled_class(244);
student2.add_enrolled_class(214);
student2.add_enrolled_class(212);
student2.add_enrolled_class(299);
student2.print();
cout << endl;

cout <<"  Student3  ";
student3.add_enrolled_class(101);
student3.add_enrolled_class(102);
student3.add_enrolled_class(103);
student3.add_enrolled_class(104);
student3.add_enrolled_class(105);
student3.add_enrolled_class(106);
student3.add_enrolled_class(107);
student3.add_enrolled_class(108);
student3.add_enrolled_class(109);
student3.add_enrolled_class(110);
student3.print();
cout << endl;

cout <<"  Student4  ";
student4.add_enrolled_class(101);
student4.add_enrolled_class(102);
student4.add_enrolled_class(103);
student4.add_enrolled_class(104);
student4.add_enrolled_class(105);
student4.add_enrolled_class(106);
student4.add_enrolled_class(107);
student4.add_enrolled_class(108);
student4.add_enrolled_class(109);
student4.add_enrolled_class(110);
student4.add_enrolled_class(111);
student4.print();
cout << endl;

return (0);
}

